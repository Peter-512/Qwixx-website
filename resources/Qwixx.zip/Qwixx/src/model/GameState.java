package src.model;

public enum GameState {
	RUNNING,
	PENALTIES,
	ROWS
}
