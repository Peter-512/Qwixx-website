package src.model;

public enum Color {
	RED,
	YELLOW,
	GREEN,
	BLUE;
}
